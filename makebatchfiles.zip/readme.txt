Make Batch Files 2.5
---------------------

This file contains useful information about "Make Batch Files", a GUI tool
that helps to create Windows batch (command) files.

================================================================================
  CONTENTS
================================================================================

  1. Overview
  2. System Requirements
  3. Installing "Make Batch Files"
  4. First steps with "Make Batch Files"
  5. Purchasing "Make Batch Files"
  6. Version Information
  7. Obtaining technical support

================================================================================
  1. Overview
================================================================================

"Make Batch Files" is a helper utility for creating Windows Batch Files.

It's main advantages over a plain text editor:

1. It operates tasks instead of commands so it is far easier to focus on problem
that you solve, not a command meaning and names.

2. It's very easy to forget all those numerious commands and switches of batch
files commands. "Make Batch Files" provides an easy to use interface with names
created and written for humans not robots.

3. It wraps a lot of batch file code into easy to understand tasks, so in fact
you write a lot less code and complete your tasks in less time.

================================================================================
  2. System Requirements
================================================================================

  -> Minimum configuration:
      - Any system running Windows 7 (or higher) operating system 
      - 20MB of free disk space

  -> Recommended Configuration:
      - Windows 7 or higher operating system
      - Pentium G or higher
      - 2GB of RAM 
      - 20MB of free disk space

================================================================================
  3. Installing "Make Batch Files"
================================================================================

Just run makebatchfiles.exe and follow the inctructions.

*IMPORTANT!*
Starting from 2016/01/01 you may get a warning message from MS Windows like this:

"Windows has protected your PC" 

which is a messy behavior of Windows SmartScreen.
Don't worry, our installer is properly signed and validated.
Just click "More info" or "Details" and then "Run anyway".
OR alternatively you can turn SmartScreen off completely. There are some videos
on this topic:
Windows 8: https://www.youtube.com/watch?v=iytBH0Zk7p4
Windows 10: https://www.youtube.com/watch?v=bGNARZf7wT4

================================================================================
  4. First steps with "Make Batch Files"
================================================================================

You can use the help file to help you get started with the environment.
Please check out this video with a small tutorial on YouTube:
http://www.youtube.com/watch?v=ZjL6nrkKbPc

================================================================================
  5. Purchasing "Make Batch Files"
================================================================================

Follow this link to get prices and order "Make Batch Files"
http://www.makebatchfiles.com/order.html

================================================================================
  6. Version Information
================================================================================

Version 2.1:
- Nearly all commands supported
+ Commands filter added

Version 1.0:
- Added more commands, primarily for working with files and folders

Version 0.1:
- First public release, only small subset of commands supported

================================================================================
  7. Obtaining technical support
================================================================================

Support contact (only for registered users of "Make Batch Files"): support@makebatchfiles.com

-----------------------------------------
Copyright(c) Make Batch Files 2016-17